# TabBar

The floating bottom bar that switches between an app's top-level sections.

**Consumer provides:** `tabs` (id, single-word `label`, `icon`, optional `badge`), `value` + `onChange`, `search` for a dedicated search tab at the trailing end.

- Navigation only, never actions; actions go in a `Toolbar`.
- Five tabs or fewer; avoid the More overflow. Never hide or disable a tab; explain empty sections inside them.
- Use filled glyphs; labels are single words. Labels render at 11px, the iOS minimum (`text-min-ios`).
- Badges (`red`) only for critical, countable information.
- Keep the bar visible everywhere except under a modal.
- Regular width (iPad) shows icon and label side by side; consider converting to a `Sidebar` there.
