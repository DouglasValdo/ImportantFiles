/* @ds-bundle: {"format":4,"namespace":"HIG","components":[{"name":"Button"},{"name":"Menu"},{"name":"Toggle"},{"name":"SegmentedControl"},{"name":"TextField"},{"name":"Slider"},{"name":"Stepper"},{"name":"Toolbar"},{"name":"TabBar"},{"name":"Sidebar"},{"name":"SearchField"},{"name":"List"},{"name":"Sheet"},{"name":"Alert"},{"name":"ActionSheet"},{"name":"ProgressBar"},{"name":"ActivityIndicator"},{"name":"Icon"}]} */
(function () {
  "use strict";
  var React = window.React;
  var h = React.createElement;
  var useState = React.useState;
  var uid = 0;
  function useId() {
    if (React.useId) return React.useId();
    var r = React.useRef(null);
    if (r.current === null) r.current = "hig-" + (++uid);
    return r.current;
  }
  function cx() {
    var out = [];
    for (var i = 0; i < arguments.length; i++) if (arguments[i]) out.push(arguments[i]);
    return out.join(" ");
  }
  function omit(o, keys) {
    var r = {};
    for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k) && keys.indexOf(k) < 0) r[k] = o[k];
    return r;
  }
  function useControlled(value, initial, onChange) {
    var s = useState(initial);
    var controlled = value !== undefined;
    var current = controlled ? value : s[0];
    function set(next) {
      if (!controlled) s[1](next);
      if (onChange) onChange(next);
    }
    return [current, set];
  }

  /* ---------- Icon: stand-in glyphs in the spirit of SF Symbols (not Apple artwork) ---------- */
  var P = {
    "chevron.right": [["path", { d: "M9 5l7 7-7 7" }]],
    "chevron.left": [["path", { d: "M15 5l-7 7 7 7" }]],
    "chevron.down": [["path", { d: "M5 9l7 7 7-7" }]],
    "chevron.up": [["path", { d: "M5 15l7-7 7 7" }]],
    "xmark": [["path", { d: "M6 6l12 12M18 6L6 18" }]],
    "plus": [["path", { d: "M12 5v14M5 12h14" }]],
    "minus": [["path", { d: "M5 12h14" }]],
    "checkmark": [["path", { d: "M5 12.5l4.5 4.5L19 7" }]],
    "magnifyingglass": [["circle", { cx: 10.5, cy: 10.5, r: 6.5 }], ["path", { d: "M15.5 15.5L20 20" }]],
    "ellipsis": [["circle", { cx: 5.5, cy: 12, r: 1.6, fill: "currentColor", stroke: "none" }], ["circle", { cx: 12, cy: 12, r: 1.6, fill: "currentColor", stroke: "none" }], ["circle", { cx: 18.5, cy: 12, r: 1.6, fill: "currentColor", stroke: "none" }]],
    "square.and.arrow.up": [["path", { d: "M12 3v12M8 7l4-4 4 4M8.5 10H6v11h12V10h-2.5" }]],
    "square.and.pencil": [["path", { d: "M11 4H5v15h15v-6" }], ["path", { d: "M17.5 3.5l3 3L12 15H9v-3z" }]],
    "trash": [["path", { d: "M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v6M14 11v6" }]],
    "house": [["path", { d: "M4 11l8-7 8 7v9h-5v-6H9v6H4z", f: 1 }]],
    "person": [["circle", { cx: 12, cy: 8, r: 4, f: 1 }], ["path", { d: "M4 21c0-4 3.6-6 8-6s8 2 8 6z", f: 1 }]],
    "star": [["path", { d: "M12 3l2.7 5.8 6.3.7-4.7 4.3 1.3 6.2L12 16.9 6.4 20l1.3-6.2L3 9.5l6.3-.7z", f: 1 }]],
    "heart": [["path", { d: "M12 20s-7.5-4.6-7.5-10.2A4.2 4.2 0 0 1 12 7.3a4.2 4.2 0 0 1 7.5 2.5C19.5 15.4 12 20 12 20z", f: 1 }]],
    "bell": [["path", { d: "M6 16v-5a6 6 0 0 1 12 0v5l2 2H4z", f: 1 }], ["path", { d: "M10 21h4" }]],
    "folder": [["path", { d: "M3 6.5A1.5 1.5 0 0 1 4.5 5H9l2 2.5h8.5A1.5 1.5 0 0 1 21 9v9.5a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 18.5z", f: 1 }]],
    "photo": [["rect", { x: 3, y: 5, width: 18, height: 14, rx: 2.5, f: 1 }], ["path", { d: "M3.5 17l5-5 4 4 3-3 5 5", s: 1 }], ["circle", { cx: 16, cy: 9, r: 1.5, s: 1 }]],
    "envelope": [["rect", { x: 3, y: 5.5, width: 18, height: 13, rx: 2.5, f: 1 }], ["path", { d: "M4 7l8 6 8-6", s: 1 }]],
    "calendar": [["rect", { x: 3.5, y: 5, width: 17, height: 15, rx: 2.5 }], ["path", { d: "M3.5 10h17M8 3v4M16 3v4" }]],
    "gearshape": [["circle", { cx: 12, cy: 12, r: 3 }], ["path", { d: "M12 2.8v2.6M12 18.6v2.6M2.8 12h2.6M18.6 12h2.6M5.5 5.5l1.8 1.8M16.7 16.7l1.8 1.8M5.5 18.5l1.8-1.8M16.7 7.3l1.8-1.8" }], ["circle", { cx: 12, cy: 12, r: 6.6 }]],
    "info.circle": [["circle", { cx: 12, cy: 12, r: 9 }], ["path", { d: "M12 11v6" }], ["circle", { cx: 12, cy: 7.6, r: 1.2, fill: "currentColor", stroke: "none" }]],
    "exclamationmark.circle": [["circle", { cx: 12, cy: 12, r: 9 }], ["path", { d: "M12 7v6" }], ["circle", { cx: 12, cy: 16.5, r: 1.2, fill: "currentColor", stroke: "none" }]],
    "xmark.circle.fill": [["circle", { cx: 12, cy: 12, r: 10, fill: "currentColor", stroke: "none" }], ["path", { d: "M8.8 8.8l6.4 6.4M15.2 8.8l-6.4 6.4", style: { stroke: "var(--bg-primary)" } }]],
    "sidebar.left": [["rect", { x: 3, y: 5, width: 18, height: 14, rx: 2.5 }], ["path", { d: "M9 5v14M5.5 8.5h1.5M5.5 11.5h1.5" }]],
    "line.3.horizontal.decrease": [["path", { d: "M4 7h16M7 12h10M10 17h4" }]],
    "speaker.wave.2": [["path", { d: "M4 9.5h3.5L12 6v12l-4.5-3.5H4z", f: 1 }], ["path", { d: "M15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11" }]],
    "speaker": [["path", { d: "M4 9.5h3.5L12 6v12l-4.5-3.5H4z", f: 1 }]],
    "sun.max": [["circle", { cx: 12, cy: 12, r: 4 }], ["path", { d: "M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.3 5.3l1.4 1.4M17.3 17.3l1.4 1.4M5.3 18.7l1.4-1.4M17.3 6.7l1.4-1.4" }]],
    "doc.on.doc": [["rect", { x: 8, y: 8, width: 12, height: 13, rx: 2 }], ["path", { d: "M16 8V5a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h2" }]],
    "pin": [["path", { d: "M9 3h6l-1 6 3 3H7l3-3zM12 12v9" }]],
    "lock": [["rect", { x: 5, y: 10.5, width: 14, height: 10, rx: 2.5, f: 1 }], ["path", { d: "M8 10.5V8a4 4 0 0 1 8 0v2.5" }]],
    "wifi": [["path", { d: "M3 9a13 13 0 0 1 18 0M6 12.5a8.5 8.5 0 0 1 12 0M9 16a4 4 0 0 1 6 0" }], ["circle", { cx: 12, cy: 19, r: 1.3, fill: "currentColor", stroke: "none" }]],
    "airplane": [["path", { d: "M10.5 21l1.5-1 1.5 1v-2l-1-1V13l8 3v-2l-8-5V4.5a1 1 0 0 0-2 0V9l-8 5v2l8-3v5l-1 1z", fill: "currentColor", stroke: "none" }]],
    "music.note": [["path", { d: "M9 18V5l11-2v13" }], ["circle", { cx: 6.5, cy: 18, r: 2.5, f: 1 }], ["circle", { cx: 17.5, cy: 16, r: 2.5, f: 1 }]],
    "questionmark": [["path", { d: "M9 9a3 3 0 1 1 4.5 2.6c-1 .6-1.5 1.2-1.5 2.4" }], ["circle", { cx: 12, cy: 18, r: 1.2, fill: "currentColor", stroke: "none" }]]
  };

  function Icon(p) {
    var spec = P[p.name] || P.questionmark;
    var size = p.size || 20;
    var kids = spec.map(function (s, i) {
      var a = omit(s[1], ["f", "s"]);
      a.key = i;
      if (p.filled && s[1].f) { a.fill = "currentColor"; }
      if (p.filled && s[1].s) { a.style = { stroke: "var(--hig-icon-cut, var(--bg-primary))" }; }
      return h(s[0], a);
    });
    return h("svg", {
      className: cx("hig-icon", p.className),
      width: size, height: size, viewBox: "0 0 24 24",
      fill: "none", stroke: "currentColor", strokeWidth: p.weight || 2,
      strokeLinecap: "round", strokeLinejoin: "round",
      role: p.label ? "img" : undefined,
      "aria-label": p.label || undefined,
      "aria-hidden": p.label ? undefined : true,
      focusable: "false",
      style: p.color ? { color: "var(--" + p.color + ")" } : undefined
    }, kids);
  }
  Icon.names = Object.keys(P);

  /* ---------- Activity indicator ---------- */
  function ActivityIndicator(p) {
    var px = p.size === "large" ? 36 : p.size === "small" ? 16 : 20;
    var spokes = [];
    for (var i = 0; i < 8; i++) {
      spokes.push(h("i", { key: i, style: { transform: "rotate(" + (i * 45) + "deg)", opacity: 0.25 + (i / 7) * 0.75 } }));
    }
    return h("span", {
      className: cx("hig-spinner", p.inherit && "is-inherit", p.className),
      role: "progressbar", "aria-label": p.label || "In progress", "aria-busy": true,
      style: { width: px, height: px }
    }, spokes);
  }

  /* ---------- Progress bar ---------- */
  function ProgressBar(p) {
    var det = typeof p.value === "number";
    var v = det ? Math.max(0, Math.min(1, p.value)) : 0;
    return h("div", { className: cx("hig-progress", !det && "is-indeterminate", p.className) },
      (p.label || (det && p.showPercent)) ? h("div", { className: "hig-progress-label" },
        h("span", null, p.label || ""),
        det && p.showPercent ? h("span", null, Math.round(v * 100) + "%") : null) : null,
      h("div", {
        className: "hig-progress-track", role: "progressbar", "aria-label": p.label || "Progress",
        "aria-valuemin": det ? 0 : undefined, "aria-valuemax": det ? 100 : undefined, "aria-valuenow": det ? Math.round(v * 100) : undefined
      }, h("div", { className: "hig-progress-fill", style: det ? { width: (v * 100) + "%" } : undefined })));
  }

  /* ---------- Button ---------- */
  function Button(p) {
    var role = p.role || "normal";
    var variant = p.variant || (role === "primary" ? "prominent" : "glass");
    var size = p.size || "medium";
    var iconOnly = !!p.icon && (p.children === undefined || p.children === null);
    var rest = omit(p, ["variant", "role", "size", "icon", "loading", "loadingLabel", "fullWidth", "className", "children"]);
    var iconSize = size === "large" ? 22 : size === "small" ? 16 : 19;
    var label = p.loading && p.loadingLabel ? p.loadingLabel : p.children;
    return h("button", Object.assign({ type: "button" }, rest, {
      className: cx("hig-btn", "hig-btn--" + variant, "hig-btn--" + size,
        role === "destructive" && "hig-btn--destructive", role === "cancel" && "hig-btn--cancel",
        iconOnly && "hig-btn--icon", p.fullWidth && "hig-btn--full", p.loading && "is-loading", p.className),
      disabled: p.disabled || p.loading,
      "aria-busy": p.loading || undefined
    }),
      p.loading ? h(ActivityIndicator, { size: "small", inherit: true, label: p.loadingLabel || "Loading" })
        : (p.icon ? h(Icon, { name: p.icon, size: iconSize, weight: 2.2 }) : null),
      label !== undefined && label !== null && !(p.loading && iconOnly) ? h("span", null, label) : null);
  }

  /* ---------- Toggle (switch) ---------- */
  function Toggle(p) {
    var st = useControlled(p.checked, !!p.defaultChecked, p.onChange);
    var on = !!st[0];
    return h("button", {
      type: "button", role: "switch", "aria-checked": on, "aria-label": p.label, id: p.id,
      disabled: p.disabled, className: cx("hig-switch", on && "is-on", p.className),
      onClick: function () { st[1](!on); }
    }, h("span", { className: "hig-switch-thumb" }));
  }

  /* ---------- Segmented control ---------- */
  function SegmentedControl(p) {
    var segs = p.segments || [];
    var st = useControlled(p.value, p.defaultValue !== undefined ? p.defaultValue : (segs[0] && segs[0].value), p.onChange);
    return h("div", { role: "radiogroup", "aria-label": p.label, className: cx("hig-seg", p.fullWidth && "hig-seg--full", p.className) },
      segs.map(function (s) {
        var sel = s.value === st[0];
        return h("button", {
          key: s.value, type: "button", role: "radio", "aria-checked": sel,
          "aria-label": s.icon && !s.label ? (s.accessibilityLabel || String(s.value)) : undefined,
          className: cx("hig-seg-item", sel && "is-selected"),
          onClick: function () { st[1](s.value); }
        }, s.icon && !s.label ? h(Icon, { name: s.icon, size: 17 }) : s.label);
      }));
  }

  /* ---------- Text field ---------- */
  function TextField(p) {
    var id = useId();
    var st = useControlled(p.value, p.defaultValue || "", p.onChange);
    var v = st[0] || "";
    var msgId = id + "-msg";
    var hasMsg = !!(p.error || p.hint);
    var inputProps = omit(p, ["label", "hint", "error", "secure", "clearButton", "leadingIcon", "value", "defaultValue", "onChange", "className"]);
    return h("div", { className: cx("hig-field", p.error && "has-error", p.className) },
      p.label ? h("label", { htmlFor: id, className: "hig-field-label" }, p.label) : null,
      h("div", { className: "hig-field-box" },
        p.leadingIcon ? h(Icon, { name: p.leadingIcon, size: 17 }) : null,
        h("input", Object.assign({}, inputProps, {
          id: id, type: p.secure ? "password" : (p.type || "text"), value: v,
          "aria-invalid": p.error ? true : undefined, "aria-describedby": hasMsg ? msgId : undefined,
          onChange: function (e) { st[1](e.target.value); }
        })),
        (p.clearButton !== false && v && !p.secure && !p.disabled) ? h("button", {
          type: "button", className: "hig-field-clear", "aria-label": "Clear text",
          onClick: function () { st[1](""); }
        }, h(Icon, { name: "xmark.circle.fill", size: 17 })) : null),
      hasMsg ? h("p", { id: msgId, className: cx("hig-field-msg", p.error && "is-error") },
        p.error ? h(Icon, { name: "exclamationmark.circle", size: 15 }) : null,
        h("span", null, p.error || p.hint)) : null);
  }

  /* ---------- Search field ---------- */
  function SearchField(p) {
    var st = useControlled(p.value, p.defaultValue || "", p.onChange);
    var v = st[0] || "";
    var focus = useState(false);
    var showCancel = p.showsCancelButton && (focus[0] || v);
    return h("form", {
      role: "search", className: cx("hig-search-wrap", p.className),
      onSubmit: function (e) { e.preventDefault(); if (p.onSubmit) p.onSubmit(v); }
    },
      h("div", { className: cx("hig-search", p.variant === "glass" && "hig-search--glass") },
        h(Icon, { name: "magnifyingglass", size: 17 }),
        h("input", {
          type: "search", value: v, placeholder: p.placeholder || "Search", "aria-label": p.label || p.placeholder || "Search",
          autoFocus: p.autoFocus, enterKeyHint: "search",
          onChange: function (e) { st[1](e.target.value); },
          onFocus: function () { focus[1](true); }, onBlur: function () { focus[1](false); }
        }),
        v ? h("button", { type: "button", className: "hig-search-clear", "aria-label": "Clear search", onClick: function () { st[1](""); } },
          h(Icon, { name: "xmark.circle.fill", size: 17 })) : null),
      showCancel ? h(Button, { variant: "glass", icon: "xmark", "aria-label": "Cancel search", onClick: function () { st[1](""); if (p.onCancel) p.onCancel(); } }) : null);
  }

  /* ---------- List ---------- */
  function List(p) {
    return h("div", { className: cx("hig-list", "hig-list--" + (p.listStyle || "insetGrouped"), p.className) }, p.children);
  }
  function ListSection(p) {
    return h("section", { className: "hig-list-section", "aria-label": typeof p.header === "string" ? p.header : undefined },
      p.header ? h("h3", { className: "hig-list-header" }, p.header) : null,
      h("div", { className: "hig-list-group", role: "list" }, p.children),
      p.footer ? h("p", { className: "hig-list-footer" }, p.footer) : null);
  }
  function ListRow(p) {
    var acc = p.accessory;
    var isButton = !!p.onClick && acc !== "toggle";
    var content = [
      p.icon ? h("span", { key: "i", className: "hig-row-icon", style: { background: "var(--" + (p.iconColor || "accent") + ")" } },
        h(Icon, { name: p.icon, size: 18, filled: true, weight: 2 })) : null,
      h("span", { key: "t", className: "hig-row-text" },
        h("span", { className: cx("hig-row-title", p.destructive && "is-destructive") }, p.title),
        p.subtitle ? h("span", { className: "hig-row-subtitle" }, p.subtitle) : null),
      (p.detail !== undefined && p.detail !== null) ? h("span", { key: "d", className: "hig-row-detail" }, p.detail) : null,
      acc === "chevron" ? h(Icon, { key: "a", name: "chevron.right", size: 14, weight: 2.6, className: "hig-row-chevron" }) : null,
      acc === "checkmark" ? h(Icon, { key: "a", name: "checkmark", size: 17, weight: 2.6, className: "hig-row-check" }) : null,
      acc === "toggle" ? h(Toggle, { key: "a", checked: p.checked, defaultChecked: p.defaultChecked, onChange: p.onToggle, label: typeof p.title === "string" ? p.title : undefined, disabled: p.disabled }) : null,
      acc === "info" ? h("button", { key: "a", type: "button", className: "hig-row-info", "aria-label": "More info", onClick: p.onInfo }, h(Icon, { name: "info.circle", size: 21 })) : null
    ];
    var cls = cx("hig-row", p.icon && "has-icon", p.selected && "is-selected");
    var inner = isButton
      ? h("button", { type: "button", className: cls, onClick: p.onClick, disabled: p.disabled, "aria-current": p.selected ? "true" : undefined, "aria-pressed": acc === "checkmark" ? true : undefined }, content)
      : h("div", { className: cls }, content);
    return h("div", { role: "listitem", className: "hig-row-cell" }, inner);
  }
  List.Section = ListSection;
  List.Row = ListRow;

  /* ---------- Toolbar ---------- */
  function Toolbar(p) {
    var large = !!p.largeTitle;
    return h("header", { className: cx("hig-toolbar", p.scrollEdge !== false && "has-edge", p.className) },
      h("div", { className: "hig-toolbar-row" },
        h("div", { className: "hig-toolbar-leading" }, p.leading),
        h("div", { className: "hig-toolbar-title" }, (!large && p.title) ? [
          h("span", { key: "t", className: "ios-headline" }, p.title),
          p.subtitle ? h("span", { key: "s", className: "hig-toolbar-subtitle" }, p.subtitle) : null] : null),
        h("div", { className: "hig-toolbar-trailing" }, p.trailing)),
      large ? h("h1", { className: "hig-toolbar-large ios-large-title" }, p.title) : null);
  }
  function ToolbarGroup(p) {
    return h("div", { className: cx("hig-toolbar-group", "hig-glass", p.className), role: "group", "aria-label": p.label }, p.children);
  }
  function ToolbarItem(p) {
    var hasText = !p.icon && p.label;
    return h("button", {
      type: "button", className: cx("hig-toolbar-item", p.prominent && "is-prominent", hasText && "has-text", p.className),
      "aria-label": p.icon ? p.label : undefined, title: p.icon ? p.label : undefined,
      onClick: p.onClick, disabled: p.disabled
    }, p.icon ? h(Icon, { name: p.icon, size: 19, weight: 2.2 }) : p.label);
  }
  Toolbar.Group = ToolbarGroup;
  Toolbar.Item = ToolbarItem;

  /* ---------- Tab bar ---------- */
  function TabBar(p) {
    var tabs = p.tabs || [];
    var st = useControlled(p.value, p.defaultValue !== undefined ? p.defaultValue : (tabs[0] && tabs[0].id), p.onChange);
    return h("nav", { className: cx("hig-tabbar", p.className), "aria-label": p.label || "Sections" },
      h("div", { className: "hig-tabbar-tabs hig-glass", role: "tablist" },
        tabs.map(function (t) {
          var on = t.id === st[0];
          return h("button", {
            key: t.id, type: "button", role: "tab", "aria-selected": on,
            className: cx("hig-tab", on && "is-selected"), onClick: function () { st[1](t.id); }
          },
            h("span", { className: "hig-tab-icon" },
              h(Icon, { name: t.icon, size: 22, filled: true }),
              (t.badge !== undefined && t.badge !== null) ? h("span", { className: "hig-badge", "aria-label": t.badge + " new" }, t.badge) : null),
            h("span", { className: "hig-tab-label" }, t.label));
        })),
      p.search ? h("button", {
        type: "button", "aria-label": "Search", role: "tab", "aria-selected": st[0] === "search",
        className: cx("hig-tabbar-search", "hig-glass", st[0] === "search" && "is-selected"),
        onClick: function () { st[1]("search"); }
      }, h(Icon, { name: "magnifyingglass", size: 22, weight: 2.2 })) : null);
  }

  /* ---------- Sidebar ---------- */
  function Sidebar(p) {
    var sections = p.sections || [];
    var first = sections[0] && sections[0].items[0] && sections[0].items[0].id;
    var st = useControlled(p.value, p.defaultValue !== undefined ? p.defaultValue : first, p.onChange);
    return h("nav", { className: cx("hig-sidebar", "hig-glass", p.compact && "hig-sidebar--compact", p.className), "aria-label": p.label || "Sidebar" },
      p.title ? h("h2", { className: "hig-sidebar-title ios-title-3" }, p.title) : null,
      sections.map(function (sec, si) {
        return h("div", { key: si, className: "hig-sidebar-section" },
          sec.title ? h("h3", { className: "hig-sidebar-section-title" }, sec.title) : null,
          sec.items.map(function (it) {
            var on = it.id === st[0];
            return h("button", {
              key: it.id, type: "button", className: cx("hig-sidebar-item", on && "is-selected"),
              "aria-current": on ? "page" : undefined, onClick: function () { st[1](it.id); }
            },
              it.icon ? h(Icon, { name: it.icon, size: p.compact ? 16 : 20, color: on ? undefined : it.iconColor }) : null,
              h("span", { className: "hig-sidebar-item-label" }, it.label),
              (it.count !== undefined && it.count !== null) ? h("span", { className: "hig-sidebar-count" }, it.count) : null);
          }));
      }));
  }

  /* ---------- Sheet ---------- */
  function Sheet(p) {
    var tid = useId();
    if (p.open === false) return null;
    return h("div", { className: cx("hig-layer", p.inline && "is-inline", p.className) },
      h("div", { className: "hig-scrim", onClick: p.onCancel }),
      h("div", { role: "dialog", "aria-modal": true, "aria-labelledby": tid, className: cx("hig-sheet", "hig-sheet--" + (p.detent || "large")) },
        p.grabber !== false ? h("div", { className: "hig-sheet-grabber", "aria-hidden": true }) : null,
        h("div", { className: "hig-sheet-bar" },
          p.onCancel ? h(Button, { variant: "glass", icon: "xmark", "aria-label": p.cancelLabel || "Cancel", onClick: p.onCancel }) : h("span"),
          h("h2", { id: tid, className: "ios-headline" }, p.title),
          p.onDone ? h(Button, { variant: "prominent", role: "primary", icon: "checkmark", "aria-label": p.doneLabel || "Done", onClick: p.onDone, disabled: p.doneDisabled }) : h("span")),
        h("div", { className: "hig-sheet-body" }, p.children)));
  }

  /* ---------- Alert ---------- */
  function Alert(p) {
    var tid = useId();
    if (p.open === false) return null;
    var acts = (p.actions || []).slice(0, 3);
    var stacked = p.stacked || acts.length > 2;
    var cancel = acts.filter(function (a) { return a.role === "cancel"; });
    var others = acts.filter(function (a) { return a.role !== "cancel"; });
    var ordered = stacked ? others.concat(cancel) : cancel.concat(others);
    return h("div", { className: cx("hig-layer", "is-center", p.inline && "is-inline", p.className) },
      h("div", { className: "hig-scrim" }),
      h("div", { role: "alertdialog", "aria-modal": true, "aria-labelledby": tid, className: "hig-alert" },
        h("h2", { id: tid, className: "hig-alert-title" }, p.title),
        p.message ? h("p", { className: "hig-alert-message" }, p.message) : null,
        p.children ? h("div", { className: "hig-alert-body" }, p.children) : null,
        h("div", { className: cx("hig-alert-actions", stacked && "is-stacked") },
          ordered.map(function (a, i) {
            return h(Button, {
              key: i, size: "medium", fullWidth: stacked,
              variant: a.isDefault ? "prominent" : "glass",
              role: a.role === "destructive" ? "destructive" : a.role === "cancel" ? "cancel" : "normal",
              onClick: a.onSelect, autoFocus: a.isDefault || undefined
            }, a.label);
          }))));
  }

  /* ---------- Action sheet (confirmation dialog) ---------- */
  function ActionSheet(p) {
    if (p.open === false) return null;
    var acts = (p.actions || []).filter(function (a) { return a.role !== "cancel"; });
    var destructive = acts.filter(function (a) { return a.role === "destructive"; });
    var rest = acts.filter(function (a) { return a.role !== "destructive"; });
    var ordered = destructive.concat(rest);
    return h("div", { className: cx("hig-layer", p.inline && "is-inline", p.className) },
      h("div", { className: "hig-scrim", onClick: p.onCancel }),
      h("div", { role: "dialog", "aria-modal": true, "aria-label": p.title || "Choose an action", className: "hig-actionsheet" },
        h("div", { className: "hig-actionsheet-group" },
          (p.title || p.message) ? h("div", { className: "hig-actionsheet-head" },
            p.title ? h("strong", null, p.title) : null, p.message ? h("span", null, p.message) : null) : null,
          ordered.map(function (a, i) {
            return h("button", { key: i, type: "button", className: cx("hig-actionsheet-btn", a.role === "destructive" && "is-destructive"), onClick: a.onSelect }, a.label);
          })),
        h("div", { className: "hig-actionsheet-group" },
          h("button", { type: "button", className: "hig-actionsheet-btn is-cancel", onClick: p.onCancel }, p.cancelLabel || "Cancel"))));
  }

  /* ---------- Menu ---------- */
  function Menu(p) {
    var items = p.items || [];
    var anyCheck = items.some(function (it) { return it.checked !== undefined; });
    return h("div", { role: "menu", "aria-label": p.title || p.label, className: cx("hig-menu", p.compact && "hig-menu--compact", p.className) },
      p.title ? h("div", { className: "hig-menu-title" }, p.title) : null,
      items.map(function (it, i) {
        if (it.separator) return h("div", { key: i, role: "separator", className: "hig-menu-sep" });
        return h("button", {
          key: i, type: "button", role: it.checked !== undefined ? "menuitemcheckbox" : "menuitem",
          "aria-checked": it.checked !== undefined ? !!it.checked : undefined,
          disabled: it.disabled, className: cx("hig-menu-item", it.role === "destructive" && "is-destructive"),
          onClick: it.onSelect
        },
          anyCheck ? h("span", { className: "hig-menu-check" }, it.checked ? h(Icon, { name: "checkmark", size: p.compact ? 12 : 15, weight: 2.6 }) : null) : null,
          h("span", { className: "hig-menu-label" }, it.label),
          it.shortcut ? h("span", { className: "hig-menu-shortcut", "aria-hidden": true }, it.shortcut) : null,
          it.icon ? h(Icon, { name: it.icon, size: p.compact ? 14 : 19 }) : null);
      }));
  }

  /* ---------- Slider ---------- */
  function Slider(p) {
    var min = p.min !== undefined ? p.min : 0, max = p.max !== undefined ? p.max : 1;
    var st = useControlled(p.value, p.defaultValue !== undefined ? p.defaultValue : (min + max) / 2, p.onChange);
    var pct = ((st[0] - min) / (max - min)) * 100;
    return h("div", { className: cx("hig-slider", p.className) },
      p.minimumIcon ? h(Icon, { name: p.minimumIcon, size: 18 }) : null,
      h("input", {
        type: "range", min: min, max: max, step: p.step !== undefined ? p.step : "any", value: st[0],
        "aria-label": p.label, "aria-valuetext": p.valueText, disabled: p.disabled,
        style: { "--hig-pct": pct + "%" },
        onChange: function (e) { st[1](Number(e.target.value)); }
      }),
      p.maximumIcon ? h(Icon, { name: p.maximumIcon, size: 18 }) : null);
  }

  /* ---------- Stepper ---------- */
  function Stepper(p) {
    var min = p.min !== undefined ? p.min : -Infinity, max = p.max !== undefined ? p.max : Infinity, step = p.step || 1;
    var st = useControlled(p.value, p.defaultValue !== undefined ? p.defaultValue : 0, p.onChange);
    var v = st[0];
    return h("div", { className: cx("hig-stepper", p.className), role: "group", "aria-label": p.label },
      p.label ? h("span", { className: "hig-stepper-label" }, p.label) : null,
      h("span", { className: "hig-stepper-value", "aria-live": "polite" }, p.format ? p.format(v) : v),
      h("span", { className: "hig-stepper-ctl" },
        h("button", { type: "button", className: "hig-stepper-btn", "aria-label": "Decrease", disabled: p.disabled || v - step < min, onClick: function () { st[1](v - step); } }, h(Icon, { name: "minus", size: 16, weight: 2.4 })),
        h("span", { className: "hig-stepper-div", "aria-hidden": true }),
        h("button", { type: "button", className: "hig-stepper-btn", "aria-label": "Increase", disabled: p.disabled || v + step > max, onClick: function () { st[1](v + step); } }, h(Icon, { name: "plus", size: 16, weight: 2.4 }))));
  }

  var api = {
    Button: Button, Menu: Menu, Toggle: Toggle, SegmentedControl: SegmentedControl, TextField: TextField,
    Slider: Slider, Stepper: Stepper, Toolbar: Toolbar, ToolbarGroup: ToolbarGroup, ToolbarItem: ToolbarItem,
    TabBar: TabBar, Sidebar: Sidebar, SearchField: SearchField, List: List, ListSection: ListSection, ListRow: ListRow,
    Sheet: Sheet, Alert: Alert, ActionSheet: ActionSheet, ProgressBar: ProgressBar, ActivityIndicator: ActivityIndicator, Icon: Icon
  };
  window.HIG = window.HIG || {};
  Object.assign(window.HIG, api);
})();
