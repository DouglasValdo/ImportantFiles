# Slider

A track and thumb for choosing a value in a continuous range.

**Consumer provides:** `label`, `min`/`max`/`step`, `value` + `onChange`, optional `minimumIcon`/`maximumIcon` and `valueText` for VoiceOver.

- Minimum is leading, maximum trailing; the filled track runs from the minimum to the thumb in `accent`.
- Pair with a text field or `Stepper` when exact values matter.
- Never use a slider for audio volume on iOS; use the system volume view.
- Customize the look only if it adds meaning.
