# Sheet

A card that slides up for a scoped task related to the current context.

**Consumer provides:** `title`, `children`, `onCancel` (close glyph, leading) and `onDone` (checkmark, prominent, trailing), `detent` (large or medium), `open`.

- Show one sheet at a time; close it before presenting another.
- Pair Done with Cancel (or Back); never show Cancel, Done and Back together.
- Support swipe down to dismiss; if there are unsaved changes, confirm with an `ActionSheet`.
- Medium detent suits progressive disclosure (sharing); compose sheets open at full height.
- Long or complex flows belong in a full-screen view instead.
- Background is `bg-elevated`, over `scrim`.
