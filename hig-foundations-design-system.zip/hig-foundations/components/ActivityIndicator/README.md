# ActivityIndicator

A spinner for work whose duration is unknown.

**Consumer provides:** `size`, a `label` for VoiceOver.

- Use it only while work is happening; replace it with content or placeholders as soon as possible.
- Don't label spinners on macOS; put them where the result will appear, or inside the button that started the work.
- Prefer showing placeholder content right away over a lone spinner.
