# TextField

A single-line field for short input such as a name, email or password.

**Consumer provides:** `label` (always, because the placeholder disappears), `placeholder` as a hint ("name@example.com"), `value` + `onChange`, the right `type`/`inputMode`/`autoComplete` so the matching keyboard appears, `hint`, and `error`.

- Errors sit under the field, say how to fix the problem and never blame: "Choose a password with at least 8 characters", not "Invalid password".
- Validate when people leave the field, not on every keystroke for formats like email.
- Use `secure` for passwords; never prefill a password field.
- Stack fields vertically with consistent widths; size each field to its expected content.
- The clear button sits at the trailing end; a leading icon states purpose.
- Field outline is `field-border` (hc themes reach 3:1); placeholder is `placeholder`.
