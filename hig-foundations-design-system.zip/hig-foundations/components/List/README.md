# List

Rows of data in grouped sections, the backbone of iOS settings and navigation screens.

**Consumer provides:** `List` (`listStyle` insetGrouped or plain) containing `ListSection` (`header`, `footer`) containing `ListRow` (`title`, `subtitle`, `detail`, `icon` + `iconColor`, `accessory`, `onClick`).

- `chevron` means the row drills into another view; `info` only reveals details and never navigates; `checkmark` marks the chosen option; `toggle` holds a switch.
- Keep row text short; long content goes in a detail view.
- Rows are at least 44px tall (`target-ios`). Headers and footers use the footnote style in `label-secondary`.
- Navigation lists keep the selected row highlighted (`selected`); option lists show a checkmark.
- Destructive rows (Sign Out) stand alone in their own section with `destructive`.
- Ground is `bg-grouped`; cells are `bg-grouped-secondary`.
