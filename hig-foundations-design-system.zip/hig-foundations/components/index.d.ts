import type * as React from 'react';

/** Stand-in glyph names (drawn for this system in the spirit of SF Symbols; on native, use the real SF Symbol of the same name). */
export type IconName =
  | 'chevron.right' | 'chevron.left' | 'chevron.down' | 'chevron.up' | 'xmark' | 'plus' | 'minus' | 'checkmark'
  | 'magnifyingglass' | 'ellipsis' | 'square.and.arrow.up' | 'square.and.pencil' | 'trash' | 'house' | 'person'
  | 'star' | 'heart' | 'bell' | 'folder' | 'photo' | 'envelope' | 'calendar' | 'gearshape' | 'info.circle'
  | 'exclamationmark.circle' | 'xmark.circle.fill' | 'sidebar.left' | 'line.3.horizontal.decrease'
  | 'speaker.wave.2' | 'speaker' | 'sun.max' | 'doc.on.doc' | 'pin' | 'lock' | 'wifi' | 'airplane' | 'music.note' | 'questionmark';

/** A color token name, e.g. 'blue', 'green', 'orange', 'accent', 'gray'. */
export type ColorToken = string;

export interface IconProps {
  name: IconName;
  /** Pixel size of the 24-unit glyph. Default 20. */
  size?: number;
  /** Stroke width in glyph units (symbol weight). Default 2. */
  weight?: number;
  /** Filled variant (tab bars, list row tiles). */
  filled?: boolean;
  /** Color token to tint with; otherwise inherits currentColor. */
  color?: ColorToken;
  /** Accessible name. Omit for decorative icons beside text. */
  label?: string;
  className?: string;
}
export declare function Icon(props: IconProps): React.ReactElement;

export interface ButtonProps extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, 'role'> {
  /** glass (default) | prominent (accent fill, one per view) | bordered (tinted fill) | plain (text only). */
  variant?: 'glass' | 'prominent' | 'bordered' | 'plain';
  /** HIG button role. primary implies prominent; destructive uses system red; never make a destructive button primary. */
  role?: 'normal' | 'primary' | 'cancel' | 'destructive';
  /** small (28 visual, 44 hit area) | medium (44) | large (52). */
  size?: 'small' | 'medium' | 'large';
  /** Leading glyph. With no children the button is icon-only: pass aria-label. */
  icon?: IconName;
  /** Shows an activity indicator in place of the icon and disables the button. */
  loading?: boolean;
  /** Alternate label while loading, e.g. "Checking Out…". */
  loadingLabel?: string;
  fullWidth?: boolean;
  children?: React.ReactNode;
}
export declare function Button(props: ButtonProps): React.ReactElement;

export interface ToggleProps {
  checked?: boolean;
  defaultChecked?: boolean;
  onChange?: (checked: boolean) => void;
  /** Accessible name; required when no visible row title labels it. */
  label?: string;
  disabled?: boolean;
  id?: string;
  className?: string;
}
export declare function Toggle(props: ToggleProps): React.ReactElement;

export interface Segment { value: string; label?: string; icon?: IconName; accessibilityLabel?: string }
export interface SegmentedControlProps {
  /** About 5 segments max on iPhone, 5 to 7 in wide layouts. All text or all icons. */
  segments: Segment[];
  value?: string;
  defaultValue?: string;
  onChange?: (value: string) => void;
  label?: string;
  fullWidth?: boolean;
  className?: string;
}
export declare function SegmentedControl(props: SegmentedControlProps): React.ReactElement;

export interface TextFieldProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'value' | 'defaultValue' | 'onChange'> {
  /** Visible label (the placeholder disappears while typing, so always provide one). */
  label?: string;
  placeholder?: string;
  value?: string;
  defaultValue?: string;
  onChange?: (value: string) => void;
  /** Helper text under the field. */
  hint?: string;
  /** Error text under the field: say how to fix it. */
  error?: string;
  /** Password-style field. */
  secure?: boolean;
  /** Trailing clear button. Default true. */
  clearButton?: boolean;
  /** Leading glyph that states the field's purpose. */
  leadingIcon?: IconName;
}
export declare function TextField(props: TextFieldProps): React.ReactElement;

export interface SearchFieldProps {
  /** Says what can be searched: "Search Recipes". */
  placeholder?: string;
  value?: string;
  defaultValue?: string;
  onChange?: (value: string) => void;
  onSubmit?: (value: string) => void;
  onCancel?: () => void;
  /** glass when floating in a toolbar or at the bottom; inline (fill) above a list. */
  variant?: 'inline' | 'glass';
  showsCancelButton?: boolean;
  autoFocus?: boolean;
  label?: string;
  className?: string;
}
export declare function SearchField(props: SearchFieldProps): React.ReactElement;

export interface ListProps { listStyle?: 'insetGrouped' | 'plain'; children?: React.ReactNode; className?: string }
export declare function List(props: ListProps): React.ReactElement;
export interface ListSectionProps { header?: React.ReactNode; footer?: React.ReactNode; children?: React.ReactNode }
export declare function ListSection(props: ListSectionProps): React.ReactElement;
export interface ListRowProps {
  title: React.ReactNode;
  subtitle?: React.ReactNode;
  /** Trailing value in secondary label color. */
  detail?: React.ReactNode;
  /** Leading glyph on a colored rounded tile (Settings style). */
  icon?: IconName;
  /** Color token for the tile. Default accent. */
  iconColor?: ColorToken;
  /** chevron = drills in; checkmark = chosen option; toggle = switch; info = reveals details only, never navigates. */
  accessory?: 'chevron' | 'checkmark' | 'toggle' | 'info';
  onClick?: () => void;
  onInfo?: () => void;
  checked?: boolean;
  defaultChecked?: boolean;
  onToggle?: (checked: boolean) => void;
  selected?: boolean;
  destructive?: boolean;
  disabled?: boolean;
}
export declare function ListRow(props: ListRowProps): React.ReactElement;

export interface ToolbarProps {
  /** Under 15 characters; never the app name. */
  title?: string;
  subtitle?: string;
  /** Large title that sits under the bar (iOS top-level screens). */
  largeTitle?: boolean;
  /** Back button, sidebar toggle. */
  leading?: React.ReactNode;
  /** Actions; one prominent item at most, at the trailing end. */
  trailing?: React.ReactNode;
  /** Scroll edge effect behind the floating bar. Default true. */
  scrollEdge?: boolean;
  className?: string;
}
export declare function Toolbar(props: ToolbarProps): React.ReactElement;
export interface ToolbarGroupProps { label?: string; children?: React.ReactNode; className?: string }
export declare function ToolbarGroup(props: ToolbarGroupProps): React.ReactElement;
export interface ToolbarItemProps {
  /** Accessible name, and the text when no icon is given. */
  label: string;
  icon?: IconName;
  /** The single primary action (Done, Submit). */
  prominent?: boolean;
  onClick?: () => void;
  disabled?: boolean;
  className?: string;
}
export declare function ToolbarItem(props: ToolbarItemProps): React.ReactElement;

export interface Tab { id: string; label: string; icon: IconName; badge?: number | string }
export interface TabBarProps {
  /** Navigation only, never actions. Five or fewer; single-word labels. */
  tabs: Tab[];
  value?: string;
  defaultValue?: string;
  onChange?: (id: string) => void;
  /** Adds the dedicated search tab at the trailing end (value 'search'). */
  search?: boolean;
  label?: string;
  className?: string;
}
export declare function TabBar(props: TabBarProps): React.ReactElement;

export interface SidebarItem { id: string; label: string; icon?: IconName; iconColor?: ColorToken; count?: number }
export interface SidebarSection { title?: string; items: SidebarItem[] }
export interface SidebarProps {
  /** Two levels at most: sections and items. */
  sections: SidebarSection[];
  value?: string;
  defaultValue?: string;
  onChange?: (id: string) => void;
  title?: string;
  /** macOS density (28 px rows, 13 px text). */
  compact?: boolean;
  label?: string;
  className?: string;
}
export declare function Sidebar(props: SidebarProps): React.ReactElement;

export interface SheetProps {
  title: string;
  open?: boolean;
  /** large (default) or medium (about half height). */
  detent?: 'large' | 'medium';
  /** Shows the close (xmark) button; also called on scrim tap. */
  onCancel?: () => void;
  /** Shows the done (checkmark, prominent) button. */
  onDone?: () => void;
  doneDisabled?: boolean;
  cancelLabel?: string;
  doneLabel?: string;
  grabber?: boolean;
  /** Position inside the nearest positioned ancestor instead of the viewport. */
  inline?: boolean;
  children?: React.ReactNode;
  className?: string;
}
export declare function Sheet(props: SheetProps): React.ReactElement | null;

export interface AlertAction { label: string; role?: 'normal' | 'cancel' | 'destructive'; isDefault?: boolean; onSelect?: () => void }
export interface AlertProps {
  /** Specific, at most two lines. Never "Error". */
  title: string;
  message?: string;
  /** Up to three. Cancel is never the default. */
  actions: AlertAction[];
  stacked?: boolean;
  open?: boolean;
  inline?: boolean;
  children?: React.ReactNode;
  className?: string;
}
export declare function Alert(props: AlertProps): React.ReactElement | null;

export interface ActionSheetAction { label: string; role?: 'normal' | 'destructive'; onSelect?: () => void }
export interface ActionSheetProps {
  title?: string;
  message?: string;
  actions: ActionSheetAction[];
  onCancel?: () => void;
  cancelLabel?: string;
  open?: boolean;
  inline?: boolean;
  className?: string;
}
export declare function ActionSheet(props: ActionSheetProps): React.ReactElement | null;

export interface MenuItem { label?: string; icon?: IconName; role?: 'normal' | 'destructive'; shortcut?: string; checked?: boolean; disabled?: boolean; separator?: boolean; onSelect?: () => void }
export interface MenuProps {
  items: MenuItem[];
  /** Only when it clarifies the effect ("3 Messages"). */
  title?: string;
  /** macOS density. */
  compact?: boolean;
  label?: string;
  className?: string;
}
export declare function Menu(props: MenuProps): React.ReactElement;

export interface SliderProps {
  value?: number;
  defaultValue?: number;
  min?: number;
  max?: number;
  step?: number;
  onChange?: (value: number) => void;
  minimumIcon?: IconName;
  maximumIcon?: IconName;
  label: string;
  valueText?: string;
  disabled?: boolean;
  className?: string;
}
export declare function Slider(props: SliderProps): React.ReactElement;

export interface StepperProps {
  value?: number;
  defaultValue?: number;
  min?: number;
  max?: number;
  step?: number;
  onChange?: (value: number) => void;
  label?: string;
  format?: (value: number) => React.ReactNode;
  disabled?: boolean;
  className?: string;
}
export declare function Stepper(props: StepperProps): React.ReactElement;

export interface ProgressBarProps {
  /** 0 to 1. Omit for indeterminate. */
  value?: number;
  /** Specific: "Downloading 3 of 12 photos", never "Loading". */
  label?: string;
  showPercent?: boolean;
  className?: string;
}
export declare function ProgressBar(props: ProgressBarProps): React.ReactElement;

export interface ActivityIndicatorProps { size?: 'small' | 'medium' | 'large'; label?: string; inherit?: boolean; className?: string }
export declare function ActivityIndicator(props: ActivityIndicatorProps): React.ReactElement;

declare global {
  interface Window {
    HIG: {
      Button: typeof Button; Menu: typeof Menu; Toggle: typeof Toggle; SegmentedControl: typeof SegmentedControl;
      TextField: typeof TextField; Slider: typeof Slider; Stepper: typeof Stepper; Toolbar: typeof Toolbar;
      ToolbarGroup: typeof ToolbarGroup; ToolbarItem: typeof ToolbarItem; TabBar: typeof TabBar; Sidebar: typeof Sidebar;
      SearchField: typeof SearchField; List: typeof List; ListSection: typeof ListSection; ListRow: typeof ListRow;
      Sheet: typeof Sheet; Alert: typeof Alert; ActionSheet: typeof ActionSheet; ProgressBar: typeof ProgressBar;
      ActivityIndicator: typeof ActivityIndicator; Icon: typeof Icon;
    };
  }
}
