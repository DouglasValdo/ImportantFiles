# ProgressBar

A bar that shows how far a task has advanced.

**Consumer provides:** `value` from 0 to 1 (omit it for indeterminate), a specific `label`, `showPercent`.

- Prefer determinate progress; switch from indeterminate as soon as the duration is known.
- Advance evenly and honestly; if progress stalls, say why and what people can do.
- Labels are specific ("Downloading 5 of 12 photos"), never just "Loading".
- Offer Cancel for long tasks, and Pause if cancelling loses work.
