# ActionSheet

A set of choices that follow an action people started, such as discarding a draft.

**Consumer provides:** `title`, optional `message`, `actions` (destructive ones are placed first), `onCancel`.

- Use it, not an alert, for choices tied to an intentional action.
- Include Cancel whenever a choice could destroy data; it always sits apart at the bottom.
- Keep titles to one line and avoid scrolling sheets.
