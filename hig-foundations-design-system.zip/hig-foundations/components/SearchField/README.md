# SearchField

A capsule field for searching content as people type.

**Consumer provides:** `placeholder` that names what is searched ("Search Recipes"), `value` + `onChange`, `onSubmit`, `variant` (`glass` when floating in a toolbar or at the bottom, `inline` above a list), `showsCancelButton`.

- Search starts as people type; show recent and suggested searches.
- Put search where it is easy to reach: the bottom toolbar or a search tab on iPhone, the trailing end of the toolbar on iPad and Mac. Keep one search location per app.
- Show what is being searched; offer a scope control for clear categories, defaulting to the broadest.
- Let people clear search history.
