# Stepper

A two-segment control that increments or decrements a value next to it.

**Consumer provides:** `label`, `value` + `onChange`, `min`/`max`/`step`, an optional `format`.

- Always show the affected value beside the control.
- For large changes pair it with a text field (number of print copies).
- The ends disable at `min` and `max`. macOS: consider Shift-click for 10x steps.
