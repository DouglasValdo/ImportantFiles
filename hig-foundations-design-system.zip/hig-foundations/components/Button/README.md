# Button

Buttons start an instantaneous action; use `variant` for emphasis and `role` for meaning.

**Use** `prominent` (accent fill, `role="primary"`) for the single most likely action in a view, at most one or two per view. Use `glass` (default) for everything floating over content, `bordered` for secondary actions inside content, `plain` for low-emphasis text actions.

**Consumer provides:** `children` (label) and/or `icon`, `onClick`, an `aria-label` for icon-only buttons, `loading` and `loadingLabel` for actions that are not instant.

- Labels start with a verb, few words, title-style capitals: "Add to Cart", "Check Out".
- Distinguish the preferred choice by style, never by size; buttons in a set share a size.
- `role="destructive"` paints the label `destructive` (red). Never make a destructive button primary or default.
- Hit region is at least 44x44 (`target-ios`); `small` stays 28 visually but expands its hit area.
- Use familiar glyphs for familiar actions: `square.and.arrow.up` for Share, `trash` for Delete.
- While loading, the spinner replaces the icon and an alternate label can say what is happening ("Checking Out…").
- On colorful content keep labels monochrome (`glass`); do not tint several buttons.
