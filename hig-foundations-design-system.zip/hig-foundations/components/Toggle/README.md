# Toggle

A switch for a choice between two opposing states that takes effect immediately.

**Consumer provides:** `checked` + `onChange` (or `defaultChecked`), and `label` when no visible row title names it.

- On iOS and iPadOS use the switch inside list rows (`ListRow accessory="toggle"`), where the row title is the label. Outside lists, use a `Button` that toggles.
- On is `success` (green). Change it to `accent` only when the green clashes, and keep 3:1 against the off track.
- State is shown by thumb position as well as color, never color alone.
- For more than two options use a `SegmentedControl` or a menu.
- macOS: prefer checkboxes for most settings; switches for emphasized groups.
