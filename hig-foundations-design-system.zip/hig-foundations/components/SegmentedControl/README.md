# SegmentedControl

A row of equal segments for switching between closely related views or modes.

**Consumer provides:** `segments` (`value` plus `label` or `icon` with `accessibilityLabel`), `value` + `onChange`, a `label` for the group.

- Up to about 5 segments on iPhone, 5 to 7 in wide layouts; keep segment widths equal.
- Use text or icons, never both in one control; labels are nouns in title-style capitals.
- Never mix momentary action segments with selection segments.
- For top-level app sections use a `TabBar`, not a segmented control.
- The selected thumb uses `fill-selected` on the `fill-tertiary` track.
