# Menu

Menus list commands people choose from a button, a context click or the menu bar.

**Consumer provides:** `items` (label, optional `icon`, `role`, `shortcut`, `checked`, `disabled`, `onSelect`, or `{separator:true}`), positioning, and the trigger (usually a `Button` with `icon="ellipsis"`). `compact` gives macOS density with keyboard shortcuts.

- Labels are verbs or short noun phrases in title-style capitals, no articles; end with "…" when more input follows ("Export as PDF…").
- Put frequent items first; separate up to about three groups.
- Icons: for all items in a group or none; use standard glyphs (Copy, Share, Delete).
- Destructive items go last and use `role="destructive"`.
- Context menus hide unavailable items; app menus dim them (`disabled`). Every context-menu command must also exist elsewhere in the interface.
- Show keyboard shortcuts in main menus, not in context menus. Submenus one level deep only.
- Toggled attributes use `checked`; or switch the label ("Show Map" / "Hide Map").
