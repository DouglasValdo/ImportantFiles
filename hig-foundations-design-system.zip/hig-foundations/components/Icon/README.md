# Icon

Line glyphs that stand in for SF Symbols on the web, named after their SF Symbol equivalents.

**Consumer provides:** `name`, `size`, `weight` to match adjacent text, `filled` for tab bars and row tiles, `label` when the glyph carries meaning on its own.

- These are original drawings, not Apple artwork. On native platforms use the real SF Symbol with the same name; SF Symbols may not be redistributed for the web.
- Use the standard glyph for standard actions: `square.and.arrow.up` Share, `trash` Delete, `xmark` Close, `ellipsis` More, `square.and.pencil` Compose, `magnifyingglass` Search, `line.3.horizontal.decrease` Filter.
- Outline in toolbars, filled in tab bars. Match weight and size to neighboring text.
- Icons inherit `currentColor`; give meaningful icons at least 3:1 against their ground.
