# Toolbar

The floating bar at the top of a screen with a title, navigation and the screen's key actions.

**Consumer provides:** `title` (under 15 characters, never the app name), `leading` (back button or sidebar toggle), `trailing` (actions), `largeTitle` for top-level iOS screens. Compose with `ToolbarGroup` (a glass capsule) and `ToolbarItem` (icon or text button; `prominent` for the one primary action).

- Controls float on Liquid Glass; do not paint a solid bar background. `scrollEdge` (default on) keeps the title legible over scrolling content.
- Use the standard back (`chevron.left`) and close (`xmark`) glyphs with no "Back" or "Close" text.
- Group by function, at most about three groups: leading navigation, center title, trailing actions.
- One `prominent` item at most (Done, Submit), always at the trailing end.
- Prefer glyphs over text, except words like "Edit".
- Toolbars hold actions; app sections belong in a `TabBar`.
- macOS: every toolbar item must also be a menu bar command.
