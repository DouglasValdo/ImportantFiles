# Sidebar

Leading-side navigation for apps with many sections or collections, on iPad and Mac.

**Consumer provides:** `sections` (optional `title`, `items` with id, label, icon, `iconColor`, `count`), `value` + `onChange`, `compact` for macOS density.

- No more than two levels: sections and items. Deeper hierarchies go in a split view.
- Icons default to `accent`; use a fixed `iconColor` only when the color carries meaning (VIP in `yellow`).
- Don't hide the sidebar by default; let people show and hide it.
- On iPhone, prefer a `TabBar`; a tab bar that converts to a sidebar serves both.
- Keep critical actions out of the bottom of a sidebar.
