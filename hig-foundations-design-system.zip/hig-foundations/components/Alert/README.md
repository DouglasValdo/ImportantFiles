# Alert

A modal message for critical information that needs a decision now.

**Consumer provides:** `title` (specific, at most two lines), optional `message`, `actions` (up to three; `role` cancel or destructive; `isDefault` for the preferred one).

- Use sparingly: never at launch, never for information that could appear inline, never for common undoable actions.
- Titles are specific ("Delete this draft?"), never "Error". Full sentences get sentence case and punctuation.
- Button titles are one or two words that describe the result ("Delete", "Reply"); "OK" only for purely informational alerts; never Yes/No.
- The default button sits trailing (or top of a stack), Cancel leading (or bottom). Cancel is never the default.
- Destructive styling only for destructive results people did not deliberately ask for.
