# Patterns

How Apple-quality apps behave in common situations. Each rule is from the HIG's Patterns and Inputs guidance.

## Launching and onboarding

- Launch instantly. The launch screen matches the first screen, with no text and no branding.
- Restore where people left off: screen, scroll position, selection, window placement.
- Prefer no onboarding. If needed, keep it short, skippable and hands-on; teach with in-context tips (one or two sentences, for features needing three actions or fewer).
- Ask for permissions only when a feature first needs them, with one specific sentence explaining why. Ask for ratings or purchases only after people are engaged.
- Use sensible defaults instead of setup steps.

## Modality

- Use a modal (`Sheet`, `Alert`, `ActionSheet`) only when focusing attention clearly helps. Keep the task short and give it one obvious way out.
- Never stack modals; never show more than one alert at a time.
- Confirm before closing if people would lose content.
- iOS dismissal: the close glyph at the leading edge of the sheet's bar, or swipe down. macOS: a button in the content.

## Loading

- Show content or placeholders immediately; let people keep working while more loads.
- Use a determinate `ProgressBar` when the duration is known, `ActivityIndicator` when it isn't, and say specifically what is happening.
- Download large assets in the background.

## Feedback

- Match the loudness of feedback to its importance: inline status first, `Alert` only for critical, actionable information.
- Warn only before unexpected data loss that can't be undone.
- When a command can't run, explain why.
- Combine channels: text, color, glyphs, sound and haptics, so feedback reaches everyone.

## Entering data

- Get information from the system instead of asking (contacts, location, autofill, passkeys).
- Prefer choices (pickers, menus, `SegmentedControl`) over typing.
- Support paste and drag and drop. Validate as people go; enable Next only when required fields are filled.
- Match the keyboard to the content (email, number, URL). Never prefill a password.

## Undo and redo

- Make actions undoable back to a logical point, and label what will be undone ("Undo Typing").
- Keep the standard ways: Command-Z and Shift-Command-Z, the top of the Edit menu, three-finger swipe, shake on iPhone.
- Prefer undo over confirmation alerts for common destructive actions.

## Settings

- Keep settings few and defaults good. Put options that affect one task inside that task.
- Don't duplicate system-wide settings (appearance, text size) in the app.
- Command-Comma opens settings on Mac; the window reopens on the last pane.
- Setting labels say what "on" does.

## Searching

- Put search in a primary, reachable place (bottom toolbar or search tab on iPhone, trailing toolbar on iPad and Mac) and keep one search location per app.
- Search as people type; suggest recent and predicted searches; show scope; let people clear history.

## Gestures and input

- Standard gestures keep their standard meaning: tap, swipe back from the leading edge, pull to refresh, long-press for a context menu, pinch to zoom.
- A custom gesture is only ever a shortcut for a visible control.
- Give feedback during the gesture, and make it clear when one isn't available.
- Keyboard: support Full Keyboard Access; add shortcuts only for frequent commands; Command first, Shift second, Option sparingly, Control never; list modifiers in the order Control, Option, Shift, Command.
- Pointer (iPad): pad hit areas by about 12px for bordered and 24px for borderless controls.
- Focus: tab order follows reading order; Tab moves between groups, arrow keys within a group; never move focus unless the person acted.

## Drag and drop

- Support it wherever content can move, with a menu command alternative.
- Highlight a destination only while it can accept the drop; keep dropped content selected; make drops undoable.

## Multitasking

- Always be ready to save and restore state.
- Pause activities that need attention when people switch away; finish started tasks in the background.
- Notify only when something important completes.
