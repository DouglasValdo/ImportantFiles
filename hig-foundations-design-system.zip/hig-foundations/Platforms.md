# Platforms

The same components adapt per platform. Design each one with the same care.

## iPhone (iOS)

- One or two hands, at arm's length, often for a minute at a time. Limit onscreen controls; make secondary actions discoverable with little effort.
- Put frequent controls in the middle and bottom of the screen where thumbs reach; support swipe back and swipe actions on rows.
- Navigation: `TabBar` for top-level sections (five or fewer), `Toolbar` with a large title on top-level screens, `List` for hierarchy, `Sheet` for scoped tasks.
- Search lives in the bottom toolbar or as the trailing search tab.
- Body text 17px (`ios-body`), targets 44px.
- Adapt to Dark Mode, Dynamic Type and rotation; use biometrics, payments and location with permission instead of asking people to type.

## iPhone Duo

- A foldable iPhone with an outer and an inner display. It is still iOS; standard, resizable layouts adapt on their own.
- Use size classes, not poses: the outer display is compact width, the inner display regular width. Never build per-pose layouts and avoid fixed widths.
- Keep the same features and state on both displays; the inner display may show one extra level (list and detail side by side).
- On the outer display and in landscape, toolbars and tab bars move to the side of the screen; the inner display in portrait keeps horizontal bars. Don't override the default bar placement.
- Keep content clear of reserved regions: the outer camera, the inner camera when active, and the fold when partially open. Keep important elements off the center line.
- Give every toolbar item both a title and a glyph, set visibility priorities (overflow runs bottom to top), and keep Compose-style actions visible longest.

## iPad (iPadOS)

- Use the large display to elevate content and reduce modality; prefer inline editing and popovers to full-screen transitions.
- Tab bar near the top, convertible to a `Sidebar`; toolbar and tab bar can share the top edge. Five tabs or fewer keeps continuity with iPhone.
- Design for narrow, intermediate and wide windows; windowed apps get window controls at the leading edge of the toolbar, so keep leading items clear.
- Support touch, keyboard, trackpad and Apple Pencil together; iPadOS also has a menu bar, so every command needs a menu home.

## Mac (macOS)

- Long sessions at a desk with keyboard and pointer: more content, fewer nested levels, less modality, comfortable density (`compact` `Sidebar` and `Menu`, `mac-*` text styles, 13px body, 28px targets).
- Every command lives in the menu bar in the standard order, with keyboard shortcuts; toolbar items are also menu commands.
- Windows resize, hide, move and go full screen; remember their size and position.
- Use a sidebar rather than a tab bar; context menus everywhere; customizable toolbars.
- Honor the person's accent color and appearance settings.
