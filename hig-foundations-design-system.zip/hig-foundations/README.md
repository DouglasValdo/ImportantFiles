A design system for building apps that look, feel and behave like native Apple software, distilled from Apple's Human Interface Guidelines (2026 edition, with Liquid Glass). It holds the HIG's exact system colors and type scales, size and spacing rules, and React components for the web that follow the HIG's component rules. On native platforms (SwiftUI, UIKit, AppKit), use the system components and color APIs directly and treat this system as the rulebook.

## Principles

Every decision is weighed against the eight HIG principles:

- **Purpose** - make something meaningful; focus on what matters most and make it great.
- **Agency** - let people do things their own way; stay out of the way, let them explore, make every mistake recoverable.
- **Responsibility** - act in people's best interest; be transparent, collect only what is needed.
- **Familiarity** - build on what people know; keep visuals and interactions consistent; give clear feedback.
- **Flexibility** - adapt to every person, input method, size and platform; accessibility from the start.
- **Simplicity** - be clear and direct; include just what is necessary; establish hierarchy.
- **Craft** - care about every detail: visuals, motion, wording, sound.
- **Delight** - make it human, but never mistake delight for decoration.

## The two layers

Interfaces are built from two layers. Hold this model before placing anything:

1. **Content layer** - the app's data, media and text, on `bg-*` surfaces and standard materials (`material-thin`, `material-regular`, `material-thick`). Brand color lives here and scrolls beneath the controls.
2. **Functional layer** - toolbars, tab bars, sidebars, floating buttons, menus and popovers, rendered in Liquid Glass (`glass-regular`, `.hig-glass`). It floats above content and lets content peek through.

Rules:

- Never put Liquid Glass in the content layer. The only exception is the transient thumb of a slider or switch while it is being dragged.
- Use glass sparingly in custom controls; standard components already have it.
- Use `glass-clear` only over photos and video, with `glass-dim` (black 35%) underneath when the media is bright.
- Separate floating bars from scrolling content with the scroll edge effect (`Toolbar scrollEdge`), not with solid bar backgrounds.
- Extend full-bleed background content under bars and sidebars to the window edges.

## Color

- Use semantic tokens by purpose, never by look: `label` for primary text, `label-secondary` for subtitles and detail values, `label-tertiary` only for unavailable items and placeholders, `separator` for hairlines, `link` for inline links.
- Plain screens sit on `bg-primary`, grouped settings-style screens on `bg-grouped` with cells in `bg-grouped-secondary`. Sheets and popovers use `bg-elevated` so they advance in Dark Mode.
- Fills for shapes: `fill` (switch and slider tracks), `fill-secondary` (small control backgrounds), `fill-tertiary` (fields, segmented tracks, bordered buttons), `fill-quaternary` (large areas).
- `accent` (default `blue`) is the only tint for interactive emphasis. Apply it to the background of the one primary action (prominent button), selected tabs and sidebar selection. Never tint many controls, and never use the accent for non-interactive text.
- One color, one meaning across the whole app. `destructive` (`red`) is for destructive actions and errors only; `success` (`green`) for on-states and success.
- Never rely on color alone: pair status color with a word, glyph or shape. Remember red and green can mean opposite things across cultures.
- Text on saturated fills uses `on-accent` (white; black in `dark-hc`), never a literal white.
- Every color has four values: light, dark, light increased contrast, dark increased contrast. Never offer an in-app light/dark switch; follow the system appearance.
- System and gray values are Apple's exact HIG specs. On native platforms call the APIs (`Color.blue`, `UIColor.label`), never hard-code hex.

Contrast floors (WCAG AA, as the HIG states them): text up to 17px needs 4.5:1; 18px+ or bold text needs 3:1; icons, control boundaries and the focus ring need 3:1. Known exceptions kept exact from Apple: `label-secondary` reads 3.4:1 on light grounds (use it for 18px+, semibold, or non-essential detail), `blue`, `red` and `pink` read about 3.5:1 on white (button labels are semibold, which meets the 3:1 bold floor), and `green`, `orange`, `yellow`, `mint`, `teal`, `cyan` are fills, not text, in the light theme. The increased contrast themes meet 4.5:1 for all of them.

## Typography

- Use the system font stack (`--font-sans`, SF Pro on Apple devices). Never embed or ship SF files; on Apple platforms the font is already there, elsewhere the stack falls back to the platform UI font.
- Use the text styles, not ad-hoc sizes: iOS `ios-large-title` through `ios-caption-2`, macOS `mac-large-title` through `mac-caption-2`.
- Default body is 17px on iOS (`ios-body`) and 13px on macOS (`mac-body`). Minimums: 11px iOS, 10px macOS.
- Prefer Regular, Medium, Semibold and Bold; avoid Ultralight, Thin and Light.
- Build hierarchy with weight, size and color together, and use as few typefaces as possible. `--font-rounded` (SF Pro Rounded) and `--font-serif` (New York) are the only alternates; a custom brand face belongs in headings only, and only if it supports Dynamic Type and Bold Text.
- Support text scaling to at least 200%: let rows grow, stack horizontal layouts vertically at large sizes, keep truncation minimal, and keep primary content at the top.
- Avoid tight leading for three or more lines.

## Layout and spacing

- Order content by importance from the top and leading edge; align to make it scannable; indent to show hierarchy; group with space and containers.
- Use progressive disclosure to keep screens calm.
- Lay out by available width (compact vs regular), never by device or orientation. The same features exist at every size; more space only reveals more of them (a tab bar becomes a sidebar).
- Respect safe areas: the Dynamic Island, the status bar, the home indicator, camera housings and floating bars.
- Margins: `space-16` in compact width, `space-20` in regular width. Padding around bezeled controls `space-12`, around borderless controls `space-24`. Sections are `space-24` apart.
- Hit targets: at least 44x44 (`target-ios`) on iOS and iPadOS, 28x28 (`target-mac`) on macOS, 60x60 (`target-vision`) on visionOS. A control can look smaller if its hit area meets the target.
- macOS: keep controls and critical information away from the bottom edge of a window.

## Shape

- Liquid Glass controls are capsules (`radius-capsule`): buttons, toolbar groups, the tab bar, search fields, switches.
- Nested shapes are concentric: an inner radius equals the outer radius minus the inset between them (`radius-md` 12px inside `radius-lg` 26px at a 14px inset). Custom elements inside bars must follow this too.
- `radius-lg` for grouped lists, menus, sidebars and cards; `radius-xl` for sheets and alerts.
- Elevation comes from translucency and the light rim of `shadow-glass`, plus `shadow-float` for modal surfaces. No heavy drop shadows, no colored borders, no gradients in the content layer.

## Iconography

- Apple apps use SF Symbols. Use them on native platforms. They may not be redistributed for the web, so this system ships `Icon`: original line glyphs drawn to the same grid and named after their SF Symbol equivalents. They are stand-ins, not Apple artwork.
- Use the standard glyph for standard actions: Share `square.and.arrow.up`, Delete `trash`, Close/Cancel `xmark`, Done `checkmark`, More `ellipsis`, Compose `square.and.pencil`, Search `magnifyingglass`, Filter `line.3.horizontal.decrease`, Add `plus`.
- Outline glyphs in toolbars, lists and beside text; filled glyphs in tab bars and settings row tiles.
- Match glyph weight and size to the adjacent text; keep all custom icons at the same size, stroke and perspective.
- Give meaningful icons an accessible label; mark decorative ones hidden.
- No logos inside the app beyond what context needs; never on the launch screen. Never use Apple trademarks or depict Apple hardware.

## Motion

- Motion must have a purpose: feedback, orientation, continuity. Never motion for its own sake.
- Keep feedback animation brief and precise; don't animate frequent interactions; never make people wait for an animation to finish.
- Motion follows the gesture: a view that slid up dismisses down.
- Respect Reduce Motion: replace slides and zooms with fades, tighten springs, avoid animating blur and depth. The components switch to near-instant timing automatically.
- Motion is never the only signal; pair it with text, haptics or sound.

## Writing

- Pick one voice and adapt the tone to the moment: plain and serious for errors, lighter for achievements.
- Be clear and brief; read text aloud. Most important information first.
- Buttons are verbs: "Send", "Add to Cart", not "Let's do it!". Links describe their destination, never "Click here".
- Use "tap" on touch devices and "click" on Mac.
- Choose title case for buttons, menus and titles and sentence case for body text, alerts' full-sentence titles and descriptions, and apply it everywhere.
- Avoid "we" and needless possessives: "Unable to load content", "Favorites" (not "Your Favorites").
- Errors appear next to the problem, never blame, and say how to fix it: "Choose a password with at least 8 characters." No "Oops".
- Flows start with "Get Started", continue with "Continue" or "Next", and end with "Done".
- Empty states say what to do next and offer the button to do it.

## Accessibility

- Every control has an accessible name; every icon-only button has an `aria-label`.
- Support Dynamic Type, Bold Text, Increase Contrast (the `-hc` themes), Reduce Transparency (glass turns opaque) and Reduce Motion.
- Keyboard: everything works with the keyboard alone; the focus ring is `focus-ring`, a solid 3px accent ring at 3:1 or better on every surface. Never override standard shortcuts.
- Every gesture has a visible alternative (swipe to delete also has Edit and a Delete button).
- No auto-dismissing views on a timer; no autoplaying media without controls.
- Caption audio and video; pair sound cues with haptics or visuals.

## Using the components

The components are React 18 function components on `window.HIG` (`components/bundle.js`), styled by `components/bundle.css` on top of `tokens.css`. Load React and ReactDOM 18, then tokens.css, bundle.css and bundle.js. Each component's README says what it expects; `components/index.d.ts` lists every prop. Theme with `data-theme` on `<html>`: `light`, `dark`, `light-hc`, `dark-hc`; map them from `prefers-color-scheme` and `prefers-contrast` rather than offering an in-app switch.

Sub-parts: `List` takes `ListSection` and `ListRow`; `Toolbar` takes `ToolbarGroup` and `ToolbarItem`.
